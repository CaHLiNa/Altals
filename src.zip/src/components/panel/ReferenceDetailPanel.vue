<template>
  <section class="reference-detail-panel">
    <div v-if="!selectedReference" class="reference-detail-panel__empty ui-empty-copy">
      {{ t('Select a reference to inspect its details.') }}
    </div>

    <div v-else class="reference-detail-panel__scroll">
      <div class="reference-detail-panel__hero">
        <div class="reference-detail-panel__hero-top">
          <div class="reference-detail-panel__type-label">{{ selectedReferenceTypeLabel }}</div>
          <button
            type="button"
            class="reference-detail-panel__icon-button"
            :disabled="!canOpenPdf"
            :title="t('Open PDF')"
            :aria-label="t('Open PDF')"
            @click="handleOpenPdf"
          >
            <IconFileText :size="18" :stroke-width="1.7" />
          </button>
        </div>

        <UiTextarea
          v-model="draft.title"
          :rows="3"
          shell-class="reference-detail-panel__title-input"
          :placeholder="t('Title')"
          @blur="commitTitle"
        />

        <UiInput
          v-model="draft.authorsText"
          size="sm"
          shell-class="reference-detail-panel__hero-input reference-detail-panel__hero-input--authors"
          :placeholder="t('Authors')"
          @blur="commitAuthors"
          @keydown.enter.prevent="$event.target.blur()"
        />

        <UiInput
          v-model="draft.citationKey"
          size="sm"
          shell-class="reference-detail-panel__hero-input reference-detail-panel__hero-input--key"
          :placeholder="t('Citation Key')"
          @blur="commitCitationKey"
          @keydown.enter.prevent="$event.target.blur()"
        />
      </div>

      <section class="reference-detail-panel__section">
        <div class="reference-detail-panel__section-header">
          <div class="reference-detail-panel__section-title">{{ t('Citation') }}</div>
          <button
            type="button"
            class="reference-detail-panel__icon-button"
            :title="t('Refresh Metadata')"
            :aria-label="t('Refresh Metadata')"
            @click="handleRefreshMetadata"
          >
            <IconRefresh :size="17" :stroke-width="1.7" />
          </button>
        </div>

        <div class="reference-detail-panel__kv-list">
          <div class="reference-detail-panel__kv-row">
            <span class="reference-detail-panel__kv-label">{{ t('Year') }}</span>
            <UiInput
              v-model="draft.year"
              size="sm"
              shell-class="reference-detail-panel__value-input"
              @blur="commitYear"
              @keydown.enter.prevent="$event.target.blur()"
            />
          </div>

          <div class="reference-detail-panel__kv-row">
            <span class="reference-detail-panel__kv-label">{{ t('Source') }}</span>
            <UiInput
              v-model="draft.source"
              size="sm"
              shell-class="reference-detail-panel__value-input"
              @blur="commitTextField('source')"
              @keydown.enter.prevent="$event.target.blur()"
            />
          </div>

          <div class="reference-detail-panel__kv-row">
            <span class="reference-detail-panel__kv-label">{{ t('Identifier') }}</span>
            <UiInput
              v-model="draft.identifier"
              size="sm"
              monospace
              shell-class="reference-detail-panel__value-input reference-detail-panel__value-input--mono"
              @blur="commitTextField('identifier')"
              @keydown.enter.prevent="$event.target.blur()"
            />
          </div>

          <div class="reference-detail-panel__triple-row">
            <div class="reference-detail-panel__triple-item">
              <span class="reference-detail-panel__kv-label">{{ t('Volume') }}</span>
              <UiInput
                v-model="draft.volume"
                size="sm"
                shell-class="reference-detail-panel__value-input"
                @blur="commitTextField('volume')"
                @keydown.enter.prevent="$event.target.blur()"
              />
            </div>

            <div class="reference-detail-panel__triple-item">
              <span class="reference-detail-panel__kv-label">{{ t('Issue') }}</span>
              <UiInput
                v-model="draft.issue"
                size="sm"
                shell-class="reference-detail-panel__value-input"
                @blur="commitTextField('issue')"
                @keydown.enter.prevent="$event.target.blur()"
              />
            </div>

            <div class="reference-detail-panel__triple-item">
              <span class="reference-detail-panel__kv-label">{{ t('Pages') }}</span>
              <UiInput
                v-model="draft.pages"
                size="sm"
                shell-class="reference-detail-panel__value-input"
                @blur="commitTextField('pages')"
                @keydown.enter.prevent="$event.target.blur()"
              />
            </div>
          </div>
        </div>
      </section>

      <section class="reference-detail-panel__section">
        <div class="reference-detail-panel__section-title">{{ t('Library') }}</div>

        <div class="reference-detail-panel__library-block">
          <div class="reference-detail-panel__kv-row reference-detail-panel__kv-row--top">
            <span class="reference-detail-panel__kv-label">{{ t('Rating') }}</span>
            <div class="reference-detail-panel__rating">
              <button
                v-for="value in ratingOptions"
                :key="value"
                type="button"
                class="reference-detail-panel__rating-star"
                :class="{ 'is-active': value <= draft.rating }"
                :title="`${value}`"
                @click="setRating(value)"
              >
                <IconStar :size="21" :stroke-width="1.7" />
              </button>
              <span class="reference-detail-panel__rating-value">
                {{ draft.rating }} / 5
              </span>
            </div>
          </div>

          <div class="reference-detail-panel__kv-row reference-detail-panel__kv-row--top">
            <span class="reference-detail-panel__kv-label">{{ t('Collections') }}</span>
            <div class="reference-detail-panel__token-editor">
              <div class="reference-detail-panel__token-list">
                <button
                  v-for="collectionValue in draft.collections"
                  :key="collectionValue"
                  type="button"
                  class="reference-detail-panel__token-chip"
                  @click="removeCollection(collectionValue)"
                >
                  <IconFolder :size="14" :stroke-width="1.7" />
                  <span>{{ collectionLabel(collectionValue) }}</span>
                  <IconX :size="14" :stroke-width="1.8" />
                </button>
              </div>
              <UiInput
                v-model="collectionInput"
                size="sm"
                shell-class="reference-detail-panel__token-input"
                :placeholder="t('Add collection')"
                @keydown.enter.prevent="addCollection"
              />
            </div>
          </div>

          <div class="reference-detail-panel__kv-row reference-detail-panel__kv-row--top">
            <span class="reference-detail-panel__kv-label">{{ t('Tags') }}</span>
            <div class="reference-detail-panel__token-editor">
              <div class="reference-detail-panel__token-list">
                <button
                  v-for="tag in draft.tags"
                  :key="tag"
                  type="button"
                  class="reference-detail-panel__token-chip reference-detail-panel__token-chip--tag"
                  @click="removeTag(tag)"
                >
                  <span class="reference-detail-panel__tag-dot" aria-hidden="true"></span>
                  <span>{{ tag }}</span>
                  <IconX :size="14" :stroke-width="1.8" />
                </button>
              </div>
              <UiInput
                v-model="tagInput"
                size="sm"
                shell-class="reference-detail-panel__token-input"
                :placeholder="t('Add tag')"
                @keydown.enter.prevent="addTag"
                @keydown="handleTagInputKeydown"
              />
            </div>
          </div>
        </div>
      </section>

      <section class="reference-detail-panel__section">
        <div class="reference-detail-panel__section-title">{{ t('Content') }}</div>

        <div class="reference-detail-panel__disclosures">
          <button
            type="button"
            class="reference-detail-panel__disclosure"
            :class="{ 'is-open': abstractExpanded }"
            @click="abstractExpanded = !abstractExpanded"
          >
            <IconChevronRight :size="16" :stroke-width="1.8" />
            <span>{{ t('Abstract') }}</span>
          </button>
          <div v-if="abstractExpanded" class="reference-detail-panel__disclosure-body">
            <UiTextarea
              v-model="draft.abstract"
              :rows="6"
              shell-class="reference-detail-panel__content-textarea"
              @blur="commitTextField('abstract', { multiline: true })"
            />
          </div>

          <button
            type="button"
            class="reference-detail-panel__disclosure"
            :class="{ 'is-open': notesExpanded }"
            @click="notesExpanded = !notesExpanded"
          >
            <IconChevronRight :size="16" :stroke-width="1.8" />
            <span>{{ t('Note') }}</span>
          </button>
          <div v-if="notesExpanded" class="reference-detail-panel__disclosure-body">
            <UiTextarea
              v-model="draft.note"
              :rows="6"
              shell-class="reference-detail-panel__content-textarea"
              @blur="commitNote"
            />
          </div>
        </div>
      </section>

      <section class="reference-detail-panel__section">
        <div class="reference-detail-panel__section-title">{{ t('Files') }}</div>
        <div class="reference-detail-panel__file-actions">
          <UiButton variant="secondary" size="sm" :disabled="!canOpenPdf" @click="handleOpenPdf">
            {{ t('Open PDF') }}
          </UiButton>
          <UiButton variant="secondary" size="sm" :disabled="!canOpenPdf" @click="handleRevealPdf">
            Finder
          </UiButton>
          <UiButton variant="secondary" size="sm" @click="handleAttachPdf">
            {{ t('Replace') }}
          </UiButton>
        </div>
      </section>

      <section v-if="citedInFiles.length > 0" class="reference-detail-panel__section">
        <div class="reference-detail-panel__section-title">{{ t('Cited In') }}</div>
        <div class="reference-detail-panel__linked-files">
          <button
            v-for="path in citedInFiles"
            :key="path"
            type="button"
            class="reference-detail-panel__linked-file"
            @click="editorStore.openFile(path)"
          >
            {{ getRelativePath(path) }}
          </button>
        </div>
      </section>
    </div>
  </section>
</template>

<script setup>
import { computed, reactive, ref, watch } from 'vue'
import { open } from '@tauri-apps/plugin-dialog'
import {
  IconChevronRight,
  IconFileText,
  IconFolder,
  IconRefresh,
  IconStar,
  IconX,
} from '@tabler/icons-vue'
import { useI18n } from '../../i18n'
import { getReferenceTypeLabelKey } from '../../domains/references/referencePresentation.js'
import { cslToReferenceRecord } from '../../domains/references/referenceInterop.js'
import { useEditorStore } from '../../stores/editor'
import { useReferencesStore } from '../../stores/references'
import { useToastStore } from '../../stores/toast'
import { useWorkspaceStore } from '../../stores/workspace'
import { openLocalPath } from '../../services/localFileOpen'
import { revealPathInFileManager } from '../../services/fileTreeSystem'
import { lookupByDoi, searchByMetadata } from '../../services/references/crossref.js'
import UiButton from '../shared/ui/UiButton.vue'
import UiInput from '../shared/ui/UiInput.vue'
import UiTextarea from '../shared/ui/UiTextarea.vue'

const { t } = useI18n()
const editorStore = useEditorStore()
const referencesStore = useReferencesStore()
const toastStore = useToastStore()
const workspace = useWorkspaceStore()

const ratingOptions = [1, 2, 3, 4, 5]

const draft = reactive({
  title: '',
  authorsText: '',
  citationKey: '',
  year: '',
  source: '',
  identifier: '',
  volume: '',
  issue: '',
  pages: '',
  abstract: '',
  note: '',
  rating: 0,
  collections: [],
  tags: [],
})

const collectionInput = ref('')
const tagInput = ref('')
const abstractExpanded = ref(false)
const notesExpanded = ref(false)

const selectedReference = computed(() => referencesStore.selectedReference)
const availableCollections = computed(() => referencesStore.collections)
const selectedReferenceTypeLabel = computed(() =>
  selectedReference.value
    ? t(getReferenceTypeLabelKey(selectedReference.value.typeKey || selectedReference.value.typeLabel))
    : ''
)
const selectedReferencePdfPath = computed(() => String(selectedReference.value?.pdfPath || '').trim())
const canOpenPdf = computed(() => selectedReferencePdfPath.value.length > 0)
const citedInFiles = computed(() => {
  const citationKey = String(selectedReference.value?.citationKey || '').trim()
  if (!citationKey) return []
  return referencesStore.citedIn[citationKey] || []
})

watch(
  () => selectedReference.value,
  (reference) => {
    syncDraft(reference)
  },
  { immediate: true }
)

function syncDraft(reference = null) {
  draft.title = String(reference?.title || '')
  draft.authorsText = Array.isArray(reference?.authors) ? reference.authors.join('; ') : ''
  draft.citationKey = String(reference?.citationKey || '')
  draft.year = reference?.year != null && reference?.year !== '' ? String(reference.year) : ''
  draft.source = String(reference?.source || '')
  draft.identifier = String(reference?.identifier || '')
  draft.volume = String(reference?.volume || '')
  draft.issue = String(reference?.issue || '')
  draft.pages = String(reference?.pages || '')
  draft.abstract = String(reference?.abstract || '')
  draft.note = Array.isArray(reference?.notes) ? reference.notes.join('\n\n') : ''
  draft.rating = Number(reference?.rating || 0) || 0
  draft.collections = normalizeCollectionMemberships(reference?.collections || [])
  draft.tags = Array.isArray(reference?.tags) ? [...reference.tags] : []
  collectionInput.value = ''
  tagInput.value = ''
}

function normalizeText(value = '') {
  return String(value || '').trim()
}

function normalizeAuthors(value = '') {
  return String(value || '')
    .split(/[\n;]+/g)
    .map((part) => normalizeText(part))
    .filter(Boolean)
}

function normalizeTagValues(value = '') {
  return String(value || '')
    .split(/[,\n;]+/g)
    .map((part) => normalizeText(part).replace(/^#/, ''))
    .filter(Boolean)
}

function getRelativePath(path = '') {
  const workspacePath = String(workspace.path || '').trim()
  if (!workspacePath || !String(path).startsWith(workspacePath)) return path
  return String(path).slice(workspacePath.length + 1)
}

function resolveCollection(value = '') {
  const normalized = normalizeText(value).toLowerCase()
  if (!normalized) return null
  return (
    availableCollections.value.find((collection) => String(collection.key || '').trim().toLowerCase() === normalized)
    || availableCollections.value.find((collection) => String(collection.label || '').trim().toLowerCase() === normalized)
    || null
  )
}

function normalizeCollectionMemberships(values = []) {
  return (Array.isArray(values) ? values : [])
    .map((value) => resolveCollection(value)?.key || String(value || '').trim())
    .filter(Boolean)
}

function collectionLabel(value = '') {
  return resolveCollection(value)?.label || String(value || '').trim()
}

async function updateSelectedReference(updates = {}) {
  if (!selectedReference.value?.id) return false
  return referencesStore.updateReference(workspace.globalConfigDir, selectedReference.value.id, updates)
}

async function commitTitle() {
  draft.title = String(draft.title || '').trim()
  await updateSelectedReference({ title: draft.title })
}

async function commitAuthors() {
  const authors = normalizeAuthors(draft.authorsText)
  draft.authorsText = authors.join('; ')
  await updateSelectedReference({
    authors,
    authorLine: authors.join('; '),
  })
}

async function commitCitationKey() {
  draft.citationKey = normalizeText(draft.citationKey)
  await updateSelectedReference({ citationKey: draft.citationKey })
}

async function commitYear() {
  const trimmed = normalizeText(draft.year)
  const year = trimmed ? Number.parseInt(trimmed, 10) : null
  draft.year = Number.isFinite(year) ? String(year) : ''
  await updateSelectedReference({ year: Number.isFinite(year) ? year : null })
}

async function commitTextField(field, options = {}) {
  const { multiline = false } = options
  const value = multiline ? String(draft[field] || '').trim() : normalizeText(draft[field])
  draft[field] = value
  await updateSelectedReference({ [field]: value })
}

async function commitNote() {
  draft.note = String(draft.note || '').trim()
  await updateSelectedReference({
    notes: draft.note ? [draft.note] : [],
  })
}

async function setRating(value = 0) {
  draft.rating = value
  await updateSelectedReference({ rating: value })
}

async function addCollection() {
  const label = normalizeText(collectionInput.value)
  if (!label) return

  let collection = resolveCollection(label)
  if (!collection) {
    collection = await referencesStore.createCollection(workspace.globalConfigDir, label)
  }

  if (!collection?.key) return

  const normalizedMemberships = normalizeCollectionMemberships(draft.collections)
  if (normalizedMemberships.includes(collection.key)) {
    collectionInput.value = ''
    return
  }

  draft.collections = [...normalizedMemberships, collection.key]
  collectionInput.value = ''
  await updateSelectedReference({ collections: [...draft.collections] })
}

async function removeCollection(value = '') {
  const target = resolveCollection(value)?.key || normalizeText(value)
  draft.collections = normalizeCollectionMemberships(draft.collections).filter(
    (item) => item !== target
  )
  await updateSelectedReference({ collections: [...draft.collections] })
}

async function addTag(event) {
  event?.preventDefault?.()
  const nextTags = normalizeTagValues(tagInput.value)
  if (nextTags.length === 0) return

  const existing = new Set(draft.tags.map((tag) => normalizeText(tag).toLowerCase()))
  for (const tag of nextTags) {
    const normalized = tag.toLowerCase()
    if (!existing.has(normalized)) {
      existing.add(normalized)
      draft.tags.push(tag)
    }
  }

  tagInput.value = ''
  await updateSelectedReference({ tags: [...draft.tags] })
}

function handleTagInputKeydown(event) {
  if (event.key === ',') {
    void addTag(event)
  }
}

async function removeTag(tag = '') {
  const normalizedTarget = normalizeText(tag).toLowerCase()
  draft.tags = draft.tags.filter((item) => normalizeText(item).toLowerCase() !== normalizedTarget)
  await updateSelectedReference({ tags: [...draft.tags] })
}

async function handleRefreshMetadata() {
  const reference = selectedReference.value
  if (!reference?.id) return

  try {
    let csl = null
    const identifier = String(reference.identifier || '').trim()

    if (/^10\.\d{4,9}\//i.test(identifier)) {
      csl = await lookupByDoi(identifier)
    }

    if (!csl) {
      const match = await searchByMetadata(
        reference.title,
        Array.isArray(reference.authors) ? reference.authors[0] || '' : '',
        reference.year
      )
      csl = match?.csl || null
    }

    if (!csl) {
      toastStore.show(t('No metadata match found'), {
        type: 'error',
        duration: 3200,
      })
      return
    }

    const refreshed = cslToReferenceRecord(csl, {
      id: reference.id,
      citationKey: reference.citationKey,
      pdfPath: reference.pdfPath,
      fulltextPath: reference.fulltextPath,
      collections: reference.collections,
      tags: reference.tags,
      notes: reference.notes,
      annotations: reference.annotations,
      rating: reference.rating,
      hasPdf: reference.hasPdf,
      hasFullText: reference.hasFullText,
    })

    await updateSelectedReference({
      ...refreshed,
      _source: reference._source,
      _zoteroKey: reference._zoteroKey,
      _zoteroLibrary: reference._zoteroLibrary,
      _importMethod: reference._importMethod,
      _pushedByShoulders: reference._pushedByShoulders,
      _shouldersPushPending: reference._shouldersPushPending,
    })
  } catch (error) {
    toastStore.show(error?.message || t('Failed to refresh metadata'), {
      type: 'error',
      duration: 3600,
    })
  }
}

async function handleOpenPdf() {
  if (!canOpenPdf.value) return
  await openLocalPath(selectedReferencePdfPath.value)
}

async function handleRevealPdf() {
  if (!canOpenPdf.value) return
  await revealPathInFileManager({ path: selectedReferencePdfPath.value })
}

async function handleAttachPdf() {
  if (!selectedReference.value?.id) return

  const selected = await open({
    multiple: false,
    title: t('Attach PDF'),
    filters: [{ name: 'PDF', extensions: ['pdf'] }],
  })

  if (!selected || Array.isArray(selected)) return
  await referencesStore.attachReferencePdf(
    workspace.globalConfigDir,
    selectedReference.value.id,
    String(selected)
  )
}
</script>

<style scoped>
.reference-detail-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
  background: transparent;
  color: var(--text-primary);
}

.reference-detail-panel__scroll {
  display: flex;
  flex: 1 1 auto;
  flex-direction: column;
  gap: 18px;
  min-height: 0;
  overflow: auto;
  padding: 10px 14px 18px;
}

.reference-detail-panel__hero {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.reference-detail-panel__hero-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.reference-detail-panel__type-label {
  color: color-mix(in srgb, var(--text-secondary) 78%, transparent);
  font-size: 12px;
  font-weight: 600;
  line-height: 1.2;
}

.reference-detail-panel__section {
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding-top: 14px;
  border-top: 1px solid color-mix(in srgb, var(--border-subtle) 44%, transparent);
}

.reference-detail-panel__section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.reference-detail-panel__section-title {
  color: color-mix(in srgb, var(--text-secondary) 74%, transparent);
  font-size: 12px;
  font-weight: 600;
  letter-spacing: 0.02em;
  line-height: 1.2;
}

.reference-detail-panel__empty {
  padding: 0 12px;
}

.reference-detail-panel__icon-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: color-mix(in srgb, var(--text-muted) 78%, transparent);
  cursor: pointer;
  transition:
    background-color 140ms ease,
    color 140ms ease,
    opacity 140ms ease;
}

.reference-detail-panel__icon-button:hover:not(:disabled) {
  background: color-mix(in srgb, var(--surface-hover) 8%, transparent);
  color: var(--text-primary);
}

.reference-detail-panel__icon-button:disabled {
  opacity: 0.4;
  cursor: default;
}

.reference-detail-panel__kv-list,
.reference-detail-panel__library-block,
.reference-detail-panel__disclosures,
.reference-detail-panel__linked-files {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.reference-detail-panel__kv-row {
  display: grid;
  grid-template-columns: 56px minmax(0, 1fr);
  align-items: center;
  gap: 10px;
}

.reference-detail-panel__kv-row--top {
  align-items: flex-start;
}

.reference-detail-panel__triple-row {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 12px;
}

.reference-detail-panel__triple-item {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}

.reference-detail-panel__triple-item .reference-detail-panel__kv-label {
  flex: 0 0 auto;
}

.reference-detail-panel__kv-label {
  color: color-mix(in srgb, var(--text-secondary) 72%, transparent);
  font-size: 12px;
  font-weight: 500;
  line-height: 1.35;
}

.reference-detail-panel__rating {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  flex-wrap: wrap;
}

.reference-detail-panel__rating-star {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  border: 0;
  background: transparent;
  color: color-mix(in srgb, var(--text-muted) 60%, transparent);
  cursor: pointer;
  transition: color 140ms ease;
}

.reference-detail-panel__rating-star.is-active {
  color: #ff9d0a;
}

.reference-detail-panel__rating-star :deep(svg) {
  fill: currentColor;
}

.reference-detail-panel__rating-value {
  color: color-mix(in srgb, var(--text-secondary) 78%, transparent);
  font-size: 13px;
  line-height: 1.35;
}

.reference-detail-panel__token-editor {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.reference-detail-panel__token-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.reference-detail-panel__token-chip {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  min-height: 30px;
  padding: 0 11px;
  border: 1px solid color-mix(in srgb, var(--border-subtle) 68%, transparent);
  border-radius: 999px;
  background: color-mix(in srgb, var(--surface-base) 58%, transparent);
  color: color-mix(in srgb, var(--text-primary) 92%, transparent);
  font: inherit;
  font-size: 13px;
  cursor: pointer;
}

.reference-detail-panel__token-chip--tag {
  gap: 10px;
}

.reference-detail-panel__tag-dot {
  width: 8px;
  height: 8px;
  border-radius: 999px;
  background: color-mix(in srgb, var(--text-muted) 82%, transparent);
  flex: 0 0 8px;
}

.reference-detail-panel__disclosure {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 0;
  border: 0;
  background: transparent;
  color: var(--text-primary);
  font: inherit;
  font-size: 14px;
  font-weight: 600;
  line-height: 1.35;
  cursor: pointer;
}

.reference-detail-panel__disclosure.is-open :deep(svg) {
  transform: rotate(90deg);
}

.reference-detail-panel__disclosure-body {
  padding-left: 22px;
}

.reference-detail-panel__file-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.reference-detail-panel__linked-file {
  width: 100%;
  padding: 0;
  border: 0;
  background: transparent;
  color: var(--accent);
  font-size: 13px;
  line-height: 1.55;
  text-align: left;
  cursor: pointer;
}

.reference-detail-panel__linked-file:hover {
  text-decoration: underline;
}

:deep(.reference-detail-panel__hero-input),
:deep(.reference-detail-panel__value-input),
:deep(.reference-detail-panel__token-input),
:deep(.reference-detail-panel__title-input),
:deep(.reference-detail-panel__content-textarea) {
  border: 1px solid transparent;
  background: transparent;
  box-shadow: none;
  border-radius: 8px;
}

:deep(.reference-detail-panel__title-input) {
  margin-inline: -4px;
}

:deep(.reference-detail-panel__title-input .ui-textarea-control) {
  min-height: 0;
  padding: 2px 4px;
  resize: none;
  color: var(--text-primary);
  font-size: clamp(16px, 2vw, 19px);
  font-weight: 650;
  line-height: 1.38;
  letter-spacing: -0.012em;
}

:deep(.reference-detail-panel__hero-input .ui-input-control) {
  padding: 1px 4px;
  color: color-mix(in srgb, var(--text-secondary) 88%, transparent);
  font-size: 13px;
  line-height: 1.45;
}

:deep(.reference-detail-panel__hero-input--key .ui-input-control) {
  font-family: var(--font-mono);
  color: color-mix(in srgb, var(--text-secondary) 72%, transparent);
  font-size: 12px;
}

:deep(.reference-detail-panel__value-input .ui-input-control) {
  padding: 1px 4px;
  color: color-mix(in srgb, var(--text-secondary) 90%, transparent);
  font-size: 14px;
  line-height: 1.45;
}

:deep(.reference-detail-panel__value-input--mono .ui-input-control) {
  font-family: var(--font-mono);
}

:deep(.reference-detail-panel__token-input .ui-input-control) {
  padding: 1px 4px;
  font-size: 13px;
}

:deep(.reference-detail-panel__content-textarea .ui-textarea-control) {
  min-height: 96px;
  padding: 4px;
  color: color-mix(in srgb, var(--text-secondary) 92%, transparent);
  font-size: 14px;
  line-height: 1.6;
}

:deep(.reference-detail-panel__hero-input:hover),
:deep(.reference-detail-panel__value-input:hover),
:deep(.reference-detail-panel__token-input:hover),
:deep(.reference-detail-panel__title-input:hover),
:deep(.reference-detail-panel__content-textarea:hover) {
  background: color-mix(in srgb, var(--surface-hover) 6%, transparent);
}

:deep(.reference-detail-panel__hero-input:focus-within),
:deep(.reference-detail-panel__value-input:focus-within),
:deep(.reference-detail-panel__token-input:focus-within),
:deep(.reference-detail-panel__title-input:focus-within),
:deep(.reference-detail-panel__content-textarea:focus-within) {
  border-color: color-mix(in srgb, var(--accent) 18%, transparent);
  background: color-mix(in srgb, var(--surface-hover) 8%, transparent);
  box-shadow: 0 0 0 2px color-mix(in srgb, var(--focus-ring) 52%, transparent);
}

@media (max-width: 700px) {
  .reference-detail-panel__scroll {
    padding-inline: 12px;
  }

  .reference-detail-panel__triple-row {
    grid-template-columns: 1fr;
    gap: 10px;
  }

  .reference-detail-panel__triple-item {
    display: grid;
    grid-template-columns: 64px minmax(0, 1fr);
  }
}
</style>
