<template>
  <div class="outline-panel" :class="{ 'outline-panel--embedded': embedded }">
    <div v-if="!hasOutlineSupport" class="outline-panel-empty">
      <div class="outline-panel-empty-copy text-center">
        <div class="outline-panel-empty-title">{{ t('No outline') }}</div>
        <div class="outline-panel-empty-hint">
          {{ t('Add headings to your document to create an outline.') }}
        </div>
      </div>
    </div>

    <div v-else-if="groupedOutlineSections.length === 0" class="outline-panel-empty-copy px-3 py-3">
      {{ t('No headings') }}
    </div>

    <div v-else class="outline-panel-scroll">
      <div v-for="section in groupedOutlineSections" :key="section.key" class="mb-1 last:mb-0">
        <div class="outline-panel-section-label">
          {{ section.title }}
        </div>
        <div
          v-for="item in section.items"
          :key="outlineItemKey(item)"
          class="outline-panel-row ui-list-row"
          :class="{ 'is-active': outlineItemKey(item) === activeOutlineItemKey }"
          :style="{ paddingLeft: getOutlineItemPadding(section.key, item) + 'px' }"
          @click="navigateToOutlineItem(item)"
        >
          <span v-if="getOutlineKindLabel(item.kind)" class="outline-panel-kind">
            {{ getOutlineKindLabel(item.kind) }}
          </span>
          <span class="truncate">{{ item.text }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onUnmounted, watch } from 'vue'
import { useEditorStore } from '../../stores/editor'
import { useDocumentWorkflowStore } from '../../stores/documentWorkflow'
import { useFilesStore } from '../../stores/files'
import { isMarkdown, isLatex, getViewerType } from '../../utils/fileTypes'
import { buildMarkdownOutlineItems } from '../../services/markdown/outline'
import { useI18n } from '../../i18n'

const props = defineProps({
  collapsed: { type: Boolean, default: false },
  overrideActiveFile: { type: String, default: null },
  embedded: { type: Boolean, default: false },
})
defineEmits(['toggle-collapse'])

const editorStore = useEditorStore()
const workflowStore = useDocumentWorkflowStore()
const filesStore = useFilesStore()
const { t } = useI18n()
const OUTLINE_SECTION_KEYS = [
  { key: 'contents', titleKey: 'Contents' },
  { key: 'figures', titleKey: 'Figures and tables' },
  { key: 'bibliography', titleKey: 'Bibliography' },
]

function outlineTypeForPath(path) {
  if (!path) return null
  const vt = getViewerType(path)
  if (vt === 'text' && isMarkdown(path)) return 'markdown'
  if (vt === 'text' && isLatex(path)) return 'latex'
  return null
}

function resolveOutlinePath(path) {
  if (!path) return null
  if (outlineTypeForPath(path)) return path

  const sourcePath = workflowStore.getSourcePathForPreview(path)
  if (outlineTypeForPath(sourcePath)) {
    return sourcePath
  }

  return path
}

// Determine if active file supports outline
// Use overrideActiveFile prop when provided (e.g., from right sidebar when chat tab is focused)
const activeFile = computed(() =>
  resolveOutlinePath(props.overrideActiveFile || editorStore.activeTab)
)

const fileType = computed(() => {
  return outlineTypeForPath(activeFile.value)
})

const hasOutlineSupport = computed(() => fileType.value !== null)

function currentDocumentText(path) {
  const view = editorStore.getAnyEditorView(path)
  if (view) {
    return view.state.doc.toString()
  }
  return filesStore.fileContents[path] || ''
}

const outlineItems = computed(() => {
  const path = activeFile.value
  const ft = fileType.value
  if (!path || !ft) return []

  if (ft === 'markdown') {
    const content = currentDocumentText(path)
    return content ? buildMarkdownOutlineItems(content) : []
  }

  if (ft === 'latex') {
    const content = currentDocumentText(path)
    return content ? parseLatexHeadings(content) : []
  }

  return []
})

function outlineSectionKeyForItem(item = {}) {
  if (item.kind === 'heading' || item.kind === 'appendix') return 'contents'
  if (item.kind === 'figure' || item.kind === 'table') return 'figures'
  if (item.kind === 'bibliography') return 'bibliography'
  return null
}

const groupedOutlineSections = computed(() => {
  return OUTLINE_SECTION_KEYS.map((section) => {
    const items = outlineItems.value.filter(
      (item) => outlineSectionKeyForItem(item) === section.key
    )
    return {
      ...section,
      title: t(section.titleKey),
      items,
    }
  }).filter((section) => section.items.length > 0)
})

const visibleOutlineItems = computed(() =>
  outlineItems.value.filter((item) => outlineSectionKeyForItem(item))
)

// Current heading highlight (for CM6 files)
const activeOutlineItemKey = computed(() => {
  const ft = fileType.value
  if (!ft) return ''
  const offset = editorStore.cursorOffset
  if (offset == null) return ''

  let activeItem = null
  for (let i = 0; i < visibleOutlineItems.value.length; i++) {
    const itemPath = visibleOutlineItems.value[i].filePath || activeFile.value
    if (itemPath !== activeFile.value) continue
    if (visibleOutlineItems.value[i].offset <= offset) {
      activeItem = visibleOutlineItems.value[i]
    } else {
      break
    }
  }
  return activeItem ? outlineItemKey(activeItem) : ''
})

// --- Heading parsers ---

const LATEX_SECTION_RE = /^\\(part|chapter|section|subsection|subsubsection|paragraph)\{([^}]*)\}/gm
const LATEX_LEVELS = {
  part: 1,
  chapter: 2,
  section: 3,
  subsection: 4,
  subsubsection: 5,
  paragraph: 6,
}

function parseLatexHeadings(content) {
  const result = []
  let m
  LATEX_SECTION_RE.lastIndex = 0
  while ((m = LATEX_SECTION_RE.exec(content)) !== null) {
    result.push({
      text: m[2].trim(),
      rawLevel: LATEX_LEVELS[m[1]] || 3,
      offset: m.index,
    })
  }
  const baseLevel = result.length > 0 ? Math.min(...result.map((item) => item.rawLevel)) : 1

  return result.map((item) => ({
    kind: 'heading',
    text: item.text,
    level: Math.max(1, item.rawLevel - baseLevel + 1),
    displayLevel: Math.max(1, item.rawLevel - baseLevel + 1),
    offset: item.offset,
  }))
}

// --- Navigation ---

function focusTextOffset(path, offset, attempts = 0) {
  const targetView = editorStore.getAnyEditorView(path)
  if (!targetView) {
    if (attempts < 20) {
      window.setTimeout(() => focusTextOffset(path, offset, attempts + 1), 40)
    }
    return
  }

  const pos = Math.min(Number(offset) || 0, targetView.state.doc.length)
  targetView.dispatch({
    selection: { anchor: pos },
    scrollIntoView: true,
  })
  targetView.focus()
}

function navigateToOutlineItem(item) {
  const path = activeFile.value
  if (!path) return

  const ft = fileType.value
  const targetPath = item.filePath || path

  if (ft === 'markdown' || ft === 'latex') {
    const targetPaneId = editorStore.findPaneWithTab(targetPath)?.id || editorStore.activePaneId
    editorStore.openFileInPane(targetPath, targetPaneId, { activatePane: true })
    focusTextOffset(targetPath, item.offset)
  }
}

function getOutlineKindLabel(kind) {
  if (kind === 'figure') return 'Fig'
  if (kind === 'table') return 'Tbl'
  if (kind === 'appendix') return 'Appx'
  return ''
}

function getOutlineItemPadding(sectionKey, item = {}) {
  if (sectionKey !== 'contents') return 6
  const displayLevel = Math.max(1, Number(item.displayLevel || item.level) || 1)
  return (displayLevel - 1) * 8 + 6
}

function outlineItemKey(item = {}) {
  return [
    item.filePath || activeFile.value || '',
    item.offset || 0,
    item.kind || 'heading',
    item.text || '',
  ].join('::')
}

watch(() => [activeFile.value, fileType.value], () => {}, { immediate: true })

onUnmounted(() => {})
</script>

<style scoped>
.outline-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: transparent;
  padding-top: 0;
}

.outline-panel--embedded {
  padding-top: 0;
}

.outline-panel-empty {
  display: flex;
  flex: 1 1 auto;
  align-items: center;
  justify-content: center;
  padding: 0 16px;
}

.outline-panel-empty-copy {
  font-size: var(--sidebar-font-body);
  line-height: 1.5;
  color: var(--text-muted);
}

.outline-panel-empty-title {
  font-size: var(--sidebar-font-item);
  line-height: var(--workbench-line-height-primary);
}

.outline-panel-empty-hint {
  margin-top: 4px;
  font-size: var(--sidebar-font-meta);
  line-height: var(--workbench-line-height-secondary);
  opacity: 0.7;
}

.outline-panel-scroll {
  flex: 1 1 auto;
  overflow-y: auto;
  padding: 0 0 4px;
  -webkit-mask-image: linear-gradient(
    to bottom,
    transparent 0,
    black 18px,
    black calc(100% - 18px),
    transparent 100%
  );
  mask-image: linear-gradient(
    to bottom,
    transparent 0,
    black 18px,
    black calc(100% - 18px),
    transparent 100%
  );
  -webkit-mask-size: 100% 100%;
  mask-size: 100% 100%;
  -webkit-mask-repeat: no-repeat;
  mask-repeat: no-repeat;
}

.outline-panel-section-label {
  padding: 6px 10px 5px;
  font-size: var(--sidebar-font-meta);
  font-weight: var(--workbench-weight-medium);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--text-muted);
  opacity: 0.72;
}

.outline-panel-row {
  display: flex;
  align-items: center;
  position: relative;
  min-height: 28px;
  padding: 3px 10px 3px 12px;
  border-radius: 8px;
  cursor: pointer;
  user-select: none;
  color: var(--text-secondary);
  font-size: var(--workbench-font-primary);
  line-height: var(--workbench-line-height-primary);
  opacity: 1;
  transition:
    background-color 140ms ease,
    color 140ms ease,
    box-shadow 140ms ease,
    border-color 140ms ease;
}

.outline-panel-row::before {
  content: '';
  position: absolute;
  left: 5px;
  top: 7px;
  bottom: 7px;
  width: 2px;
  border-radius: 999px;
  background: transparent;
  opacity: 0;
  transition:
    background-color 140ms ease,
    opacity 140ms ease;
}

.outline-panel-row:hover {
  background: color-mix(in srgb, var(--surface-hover) 18%, transparent);
}

.outline-panel-row.is-active {
  background: color-mix(in srgb, var(--surface-hover) 28%, transparent);
  color: var(--text-primary);
  box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--border) 12%, transparent);
}

.outline-panel-row.is-active::before {
  background: transparent;
  opacity: 0;
}

.outline-panel-kind {
  margin-right: 6px;
  flex-shrink: 0;
  font-size: var(--workbench-font-secondary);
  font-weight: var(--workbench-weight-medium);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--text-muted);
  opacity: 0.62;
}
</style>
